# Example
This example uses [wasi-sdk](https://github.com/WebAssembly/wasi-sdk).
You have to install it and then you might need to modify the wasi-sdk variable in the Makefile.

Of course this challenge can be solved in any language that has a wasm+wasi target.
